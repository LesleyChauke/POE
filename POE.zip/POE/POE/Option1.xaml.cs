﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace POE
{
    /// <summary>
    /// Interaction logic for Option1.xaml
    /// </summary>
    public partial class Option1 : Window
    {
        //creating a variable calling from Option1
        private string name = "";
        public Option1()
        {
            InitializeComponent();
        }

        private void Input_Click(object sender, RoutedEventArgs e)
        {
            //using variable to show results from text box
            name = MainText.Text;
            MainAnswer.Text = name;

            name = Maintext1.Text;
            MainAnswer1.Text = name;

            name = Maintext2.Text;
            MainAnswer2.Text = name;

            name = Maintext3.Text;
            MainAnswer3.Text = name;

            name = Maintext4.Text;
            MainAnswer4.Text = name;

            name = Maintext5.Text;
            MainAnswer5.Text = name;

            name = Maintext6.Text;
            MainAnswer6.Text = name;
            
           
        }
    }
}
