﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE
{
    internal class ExternalClass
    {
        private string[] ingredient;
        private double[] quantity;
        private string[] UnitOfMeasurement;
        private string[] showstep;
        private double[] scale;
        private double[] calories;
        private string[] group;

        static void option2()
        {

        }


        //Gets and Sets
        public string[] Ingredient
        {
            get { return ingredient; }
            set { ingredient = value; }
        }

        public double[] Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }
        public string[] UnitOfMeasurements
        {
            get { return UnitOfMeasurement; }
            set { UnitOfMeasurement = value; }
        }
        public string[] Showstep
        {
            get { return showstep; }
            set { showstep = value; }
        }
        public double[] Scale
        {
            get { return scale; }
            set { scale = value; }
        }
        public double[] Calories
        {
            get { return calories; }
            set { calories = value; }
        }
        public string[] Group
        {
            get { return group; }
            set { group = value; }
        }
        public override string ToString()
        {
            return $"The ingredient name: {Ingredient} \"Enter the number of units {Quantity}\"The unit measurement: {UnitOfMeasurements}";
        }
    }
}
